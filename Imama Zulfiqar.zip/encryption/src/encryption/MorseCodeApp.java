//
//package encryption;
//
//
// import java.util.HashMap;
//
//class MorseCodeEncryptor {
//    private final HashMap<Character, String> morseMap;
//
//    // Constructor to initialize Morse code dictionary
//    public MorseCodeEncryptor() {
//        morseMap = new HashMap<>();
//        initializeMorseMap();
//    }
//
//    // Method to fill the Morse code map
//    private void initializeMorseMap() {
//        String[] morseCodes = {".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..",  
//".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.",  
//"...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.."
//};
//
//        for (char c = 'A'; c <= 'Z'; c++) {
//            morseMap.put(c, morseCodes[c - 'A']);
//        }
//        morseMap.put(' ', "/");  // Space between words
//    }
//
//    // Method to encrypt text to Morse code
//    public String encryptToMorse(String text) {
//        StringBuilder morseText = new StringBuilder();
//        text = text.toUpperCase();  // Convert to uppercase
//
//        for (char c : text.toCharArray()) {
//            if (morseMap.containsKey(c)) {
//                morseText.append(morseMap.get(c)).append(" ");
//            }
//        }
//        return morseText.toString().trim();
//    }
//
//// derpt from morse code
//public String decryptFromMorse(String morseCode) {
//    StringBuilder result = new StringBuilder();
//    for (String code : morseCode.split(" ")) {
////        result.append(morseToText.getOrDefault(code, " ")); // Handle unknown codes
//    }
//    return result.toString();
//}
//}
//// Main class to test encryption
//public class MorseCodeApp {
//    public static void main(String[] args) {
//        MorseCodeEncryptor encryptor = new MorseCodeEncryptor();
//        String message = "HELLO WORLD";
//        String encrypted = encryptor.encryptToMorse(message);
//        System.out.println("Original: " + message);
//        System.out.println("Morse Code: " + encrypted);
//    }
//}
//   
//
